/*
 * lin1d3_driver_Cfg.h
 *
 *  Created on: Sep 14, 2018
 *      Author: Nico
 */

#ifndef LIN1D3_DRIVER_CFG_H_
#define LIN1D3_DRIVER_CFG_H_

#define lin1d3_max_supported_messages_per_node_cfg_d	(16)


#endif /* LIN1D3_DRIVER_CFG_H_ */
